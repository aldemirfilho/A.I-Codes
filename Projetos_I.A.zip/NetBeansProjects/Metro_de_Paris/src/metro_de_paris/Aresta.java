package metro_de_paris;

public class Aresta  {
    int distancia;
    Vertice vertice1;
    Vertice vertice2;

    public Aresta(int distancia, Vertice vertice1, Vertice vertice2) {
        this.distancia = distancia;
        this.vertice1 = vertice1;
        this.vertice2 = vertice2;
    }

    public int getDistancia() {
        return distancia;
    }

    public Vertice getVertice1() {
        return vertice1;
    }

    public Vertice getVertice2() {
        return vertice2;
    }
    
    
}
