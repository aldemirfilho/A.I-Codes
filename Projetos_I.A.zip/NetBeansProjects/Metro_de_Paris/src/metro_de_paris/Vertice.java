package metro_de_paris;

import java.util.ArrayList;

public class Vertice {
    int estacao;
    int dist_do_destino;
    
    java.util.ArrayList<Aresta> Arestas_adjacentes = new java.util.ArrayList<Aresta>();

    public Vertice(int estacao) {
        this.estacao = estacao;
    }
    
    public int dist_dest(Vertice atual, Vertice destino){
        int dist = 0;
        Dados distancia = new Dados();
        dist = distancia.getDist()[atual.getEstacao()-1][destino.getEstacao()-1];
        return dist;
    }

    public int getEstacao() {
        return estacao;
    }

    public void setEstacao(int estacao) {
        this.estacao = estacao;
    }

    public int getDist_do_destino() {
        return dist_do_destino;
    }

    public void setDist_do_destino(int dist_do_destino) {
        this.dist_do_destino = dist_do_destino;
    }

    public ArrayList<Aresta> getArestas_adjacentes() {
        return Arestas_adjacentes;
    }

    public void setArestas_adjacentes(ArrayList<Aresta> Arestas_adjacentes) {
        this.Arestas_adjacentes = Arestas_adjacentes;
    }
    
    
}

