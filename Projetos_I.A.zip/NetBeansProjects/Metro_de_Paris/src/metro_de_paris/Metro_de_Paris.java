package metro_de_paris;

import java.util.Scanner;

public class Metro_de_Paris {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Digite o numero da estação de partida e de destino:");
        int partida = input.nextInt();
        Vertice destino = new Vertice(input.nextInt());
        
        Linha azul = new Linha(new int []{1,2,3,4,5,6});
        Linha amarela = new Linha(new int []{10,2,9,8,5,7});
        Linha vermelha = new Linha(new int []{11,9,3,13});
        Linha verde = new Linha(new int []{12,8,4,13,14});
        
        Dados inicio = new Dados();
        java.util.ArrayList<Vertice> grafo = inicio.criar_grafo(destino);
        
        Vertice begin = grafo.get(partida - 1);
        
        java.util.ArrayList<Integer> distancias = new java.util.ArrayList<Integer>();
        for(int i = 0; i < 14; i++){
            distancias.add(Integer.MAX_VALUE);
        }
        distancias.set(begin.getEstacao(), 0);
        
        java.util.ArrayList<Integer[]> queue = new java.util.ArrayList<>();
        // Integer[1] é o vertice e Integer[2] é a distancia
        for(int i = 0; i < 14; i++){
            queue.add(new Integer[]{i,distancias.get(i)});
        }
        //dijkstra
        while(!queue.isEmpty()){
            Integer[] dequeued = queue.get(0);
            queue.remove(0);
            int vertice_index = dequeued[0];
            for (Aresta aresta : grafo.get(vertice_index).Arestas_adjacentes){
                int total = distancias.get(vertice_index) + aresta.distancia + aresta.distancia;
                //if(total);
            }
        }
    }   
}
