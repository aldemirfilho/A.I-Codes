package metro_de_paris;

public class Dados {
    int [][]dist = new int [][] {{0,11,20,27,40,43,39,28,18,10,18,30,30,32}, {11,0,9,16,29,32,28,19,11,4,17,23,21,24},
                                 {20,9,0,7,20,22,19,15,10,11,21,21,13,18}, {27,16,7,0,13,16,12,13,13,18,26,21,11,17},
                                 {40,29,20,13,0,3,2,21,25,31,38,27,16,20}, {43,32,22,16,3,0,4,23,28,33,41,30,17,20},
                                 {39,28,19,12,2,4,0,22,25,29,38,28,13,17}, {28,19,15,13,21,23,22,0,9,22,18,7,25,30},
                                 {18,11,10,13,25,28,25,9,0,13,12,12,23,28}, {10,4,11,18,31,33,29,22,13,0,20,27,20,23},
                                 {18,17,21,26,38,41,38,18,12,20,0,15,35,39}, {30,23,21,21,27,30,28,7,12,27,15,0,31,37},
                                 {30,21,13,11,16,17,13,25,23,20,35,31,0,5}, {32,24,18,17,20,20,17,30,28,23,39,37,5,0}};

    Vertice um;         Vertice oito;
    Vertice dois;       Vertice nove;
    Vertice tres;       Vertice dez;
    Vertice quatro;     Vertice onze;
    Vertice cinco;      Vertice doze;
    Vertice seis;       Vertice treze;
    Vertice sete;       Vertice quatorze;
    
    public java.util.ArrayList<Vertice> criar_grafo(Vertice destino){
        um = new Vertice(1); um.setDist_do_destino(um.dist_dest(um, destino));
        dois = new Vertice(2); dois.setDist_do_destino(dois.dist_dest(dois, destino));
        tres = new Vertice(3); tres.setDist_do_destino(tres.dist_dest(tres, destino));
        quatro = new Vertice(4); quatro.setDist_do_destino(quatro.dist_dest(quatro, destino));
        cinco = new Vertice(5); cinco.setDist_do_destino(cinco.dist_dest(cinco, destino));
        seis = new Vertice(6); seis.setDist_do_destino(seis.dist_dest(seis, destino));
        sete = new Vertice(7); sete.setDist_do_destino(sete.dist_dest(sete, destino));
        oito = new Vertice(8); oito.setDist_do_destino(oito.dist_dest(oito, destino));
        nove = new Vertice(9); nove.setDist_do_destino(nove.dist_dest(nove, destino));
        dez = new Vertice(10); dez.setDist_do_destino(dez.dist_dest(dez, destino));
        onze = new Vertice(11); onze.setDist_do_destino(onze.dist_dest(onze, destino));
        doze = new Vertice(12); doze.setDist_do_destino(doze.dist_dest(doze, destino));
        treze = new Vertice(13); treze.setDist_do_destino(treze.dist_dest(treze, destino));
        quatorze = new Vertice(14); quatorze.setDist_do_destino(quatorze.dist_dest(quatorze, destino));
        
        um.Arestas_adjacentes.add(new Aresta(0, um, um));
        um.Arestas_adjacentes.add(new Aresta(um.dist_dest(um, dois), um, dois));
        
        dois.Arestas_adjacentes.add(new Aresta(0, dois, dois));
        dois.Arestas_adjacentes.add(new Aresta(dois.dist_dest(dois, um), dois, um));
        dois.Arestas_adjacentes.add(new Aresta(dois.dist_dest(dois, nove), dois, nove));
        dois.Arestas_adjacentes.add(new Aresta(dois.dist_dest(dois, dez), dois, dez));
        dois.Arestas_adjacentes.add(new Aresta(dois.dist_dest(dois, tres), dois, tres));
        
        tres.Arestas_adjacentes.add(new Aresta(0, tres, tres));
        tres.Arestas_adjacentes.add(new Aresta(tres.dist_dest(tres, dois), tres, dois));
        tres.Arestas_adjacentes.add(new Aresta(tres.dist_dest(tres, nove), tres, nove));
        tres.Arestas_adjacentes.add(new Aresta(tres.dist_dest(tres, quatro), tres, quatro));
        tres.Arestas_adjacentes.add(new Aresta(tres.dist_dest(tres, treze), tres, treze));
        
        quatro.Arestas_adjacentes.add(new Aresta(0, quatro, quatro));
        quatro.Arestas_adjacentes.add(new Aresta(quatro.dist_dest(quatro, tres), quatro, tres));
        quatro.Arestas_adjacentes.add(new Aresta(quatro.dist_dest(quatro, oito), quatro, oito));
        quatro.Arestas_adjacentes.add(new Aresta(quatro.dist_dest(quatro, cinco), quatro, cinco));
        quatro.Arestas_adjacentes.add(new Aresta(quatro.dist_dest(quatro, treze), quatro, treze));
        
        cinco.Arestas_adjacentes.add(new Aresta(0, cinco, cinco));
        cinco.Arestas_adjacentes.add(new Aresta(cinco.dist_dest(cinco, quatro), cinco, quatro));
        cinco.Arestas_adjacentes.add(new Aresta(cinco.dist_dest(cinco, oito), cinco, oito));
        cinco.Arestas_adjacentes.add(new Aresta(cinco.dist_dest(cinco, seis), cinco, seis));
        cinco.Arestas_adjacentes.add(new Aresta(cinco.dist_dest(cinco, sete), cinco, sete));
        
        seis.Arestas_adjacentes.add(new Aresta(0, seis, seis));
        seis.Arestas_adjacentes.add(new Aresta(seis.dist_dest(seis, cinco), seis, cinco));
        
        sete.Arestas_adjacentes.add(new Aresta(0, sete, sete));
        sete.Arestas_adjacentes.add(new Aresta(sete.dist_dest(sete, cinco), sete, cinco));
        
        oito.Arestas_adjacentes.add(new Aresta(0, oito, oito));
        oito.Arestas_adjacentes.add(new Aresta(oito.dist_dest(oito, nove), oito, nove));
        oito.Arestas_adjacentes.add(new Aresta(oito.dist_dest(oito, doze), oito, doze));
        oito.Arestas_adjacentes.add(new Aresta(oito.dist_dest(oito, cinco), oito, cinco));
        oito.Arestas_adjacentes.add(new Aresta(oito.dist_dest(oito, quatro), oito, quatro));
        
        nove.Arestas_adjacentes.add(new Aresta(0, nove, nove));
        nove.Arestas_adjacentes.add(new Aresta(nove.dist_dest(nove, dois), nove, dois));
        nove.Arestas_adjacentes.add(new Aresta(nove.dist_dest(nove, onze), nove, onze));
        nove.Arestas_adjacentes.add(new Aresta(nove.dist_dest(nove, oito), nove, oito));
        nove.Arestas_adjacentes.add(new Aresta(nove.dist_dest(nove, tres), nove, tres));
        
        dez.Arestas_adjacentes.add(new Aresta(0, dez, dez));
        dez.Arestas_adjacentes.add(new Aresta(dez.dist_dest(dez, dois), dez, dois));
        
        onze.Arestas_adjacentes.add(new Aresta(0, onze, onze));
        onze.Arestas_adjacentes.add(new Aresta(onze.dist_dest(onze, nove), onze, nove));
        
        doze.Arestas_adjacentes.add(new Aresta(0, doze, doze));
        doze.Arestas_adjacentes.add(new Aresta(doze.dist_dest(doze, oito), doze, oito));
        
        treze.Arestas_adjacentes.add(new Aresta(0, treze, treze));
        treze.Arestas_adjacentes.add(new Aresta(treze.dist_dest(treze, tres), treze, tres));
        treze.Arestas_adjacentes.add(new Aresta(treze.dist_dest(treze, quatro), treze, quatro));
        treze.Arestas_adjacentes.add(new Aresta(treze.dist_dest(treze, quatorze), treze, quatorze));
        
        quatorze.Arestas_adjacentes.add(new Aresta(0, quatorze, quatorze));
        quatorze.Arestas_adjacentes.add(new Aresta(quatorze.dist_dest(quatorze, treze), quatorze, treze));
        
        java.util.ArrayList<Vertice> Grafo = new java.util.ArrayList<Vertice>();
        Grafo.add(um);        Grafo.add(dois);
        Grafo.add(tres);      Grafo.add(quatro);
        Grafo.add(cinco);     Grafo.add(seis);
        Grafo.add(sete);      Grafo.add(oito);
        Grafo.add(nove);      Grafo.add(dez);
        Grafo.add(onze);      Grafo.add(doze);
        Grafo.add(treze);     Grafo.add(quatorze);
        
        return Grafo;
    }
    
    public int[][] getDist() {
        return dist;
    }
}


























  /*int E1_E2=11;   int E2_E3=9;    int E3_E4=7;    int E4_E5=13;   int E5_E6=3;    int E6_E7=4;    int E7_E8=22;   int E8_E9=9;    int E9_E10=13;  int E10_E11=20;  int E11_E12=15;  int E12_E13=31; int E13_14=5;
    int E1_E3=20;   int E2_E4=16;   int E3_E5=20;   int E4_E6=16;   int E5_E7=2;    int E6_E8=23;   int E7_E9=25;   int E8_E10=22;  int E9_E11=12;  int E10_E12=27;  int E11_E13=35;  int E12_E14=37;
    int E1_E4=27;   int E2_E5=29;   int E3_E6=22;   int E4_E7=12;   int E5_E8=21;   int E6_E9=28;   int E7_E10=29;  int E8_E11=18;  int E9_E12=12;  int E10_E13=20;  int E11_E14=39;
    int E1_E5=40;   int E2_E6=32;   int E3_E7=19;   int E4_E8=13;   int E5_E9=25;   int E6_E10=33;  int E7_E11=38;  int E8_E12=7;   int E9_E13=23;  int E10_E14=23;
    int E1_E6=43;   int E2_E7=28;   int E3_E8=15;   int E4_E9=13;   int E5_E10=31;  int E6_E11=41;  int E7_E12=28;  int E8_E13=25;  int E9_E14=28;
    int E1_E7=39;   int E2_E8=19;   int E3_E9=10;   int E4_E10=18;  int E5_E11=38;  int E6_E12=30;  int E7_E13=13;  int E8_E14=30;
    int E1_E8=28;   int E2_E9=11;   int E3_E10=11;  int E4_E11=26;  int E5_E12=27;  int E6_E13=17;  int E7_E14=17; 
    int E1_E9=18;   int E2_E10=4;   int E3_E11=21;  int E4_E12=21;  int E5_E13=16;  int E6_E14=20;   
    int E1_E10=10;  int E2_E11=17;  int E3_E12=21;  int E4_E13=11;  int E5_E14=20;
    int E1_E11=18;  int E2_E12=23;  int E3_E13=13;  int E4_E14=17;
    int E1_E12=30;  int E2_E13=21;  int E3_E14=18;
    int E1_E13=30;  int E2_E14=24;     
    int E1_E14=32;*/
