# I.A.
Atividade de I.A. referente à parte de busca
