package missionarios_canibais;

import java.util.ArrayList;

public class Node {
    Estado estado;
    Node pai;
    java.util.ArrayList<Node> Filhos;

    public Node() {
        this.estado = new Estado(3,0,3,0);
        this.pai = null;
        this.Filhos = new java.util.ArrayList<Node>();
    }

    public Node(Estado estado, Node pai) {
        this.estado = estado;
        this.pai = pai;
        this.Filhos = new java.util.ArrayList<Node>();
    }
    
    public void check_esq_dir(int c_esq, int m_esq, int c_dir, int m_dir){
        if((c_dir <= m_dir || m_dir == 0) && (c_esq <= m_esq || m_esq == 0)){
            if(c_dir == 3 && m_dir == 3)
                check_dir_esq(c_esq, m_esq, c_dir, m_dir);
            if(c_dir>1 && (estado.canibais_esq!=c_esq+2)) //voltar dois canibais
                check_dir_esq(c_esq+2, m_esq, c_dir-2, m_dir);
            if(c_dir>0 && (estado.canibais_esq!=c_esq+1))//voltar um canibal
                check_dir_esq(c_esq+1,m_esq,c_dir-1,m_dir);
            if(m_dir>1 && estado.miss_esq!=m_esq+2) //voltar dois missionarios
                check_dir_esq(c_esq, m_esq+2, c_dir, m_dir-2);
            if(m_dir>0 && estado.miss_esq!=m_esq+1) //voltar um missionario
                check_dir_esq(c_esq, m_esq+1, c_dir, m_dir-1);
            if(m_dir>0 && c_dir>0 && estado.miss_esq!=m_esq+1 && estado.canibais_esq!=c_esq+1) //voltar um de cada
                check_dir_esq(c_esq+1, m_esq+1, c_dir-1, m_dir-1);
        }
    }

    @Override
    public String toString() {
        return "Esquerda : (Canibais, Missionarios) : "
                + "( " + this.estado.canibais_esq + " , " + estado.miss_esq + ")\n"
                + "Direita:(Canibais, Missionarios) : "
                + "( " + this.estado.canibais_dir + " , " + estado.miss_dir + ")";
    }
    
    public void check_dir_esq(int c_esq, int m_esq, int c_dir, int m_dir){
        if((c_dir <= m_dir || m_dir == 0) && (c_esq <= m_esq || m_esq == 0)){
            Estado estado_check = new Estado(c_esq,c_dir,m_esq,m_dir);
            Node node = new Node(estado_check, this);
            this.Filhos.add(node);
        }
    }
    public boolean isSolution(){
        return estado.canibais_dir == 3 && estado.miss_dir == 3;
    }
    public void gerar_filho(){
        if(this.estado.canibais_esq > 1)
            this.check_esq_dir(this.estado.canibais_esq-2, this.estado.miss_esq, this.estado.canibais_dir+2, this.estado.miss_dir);
        if(this.estado.canibais_esq > 0)
            this.check_esq_dir(this.estado.canibais_esq-1, this.estado.miss_esq, this.estado.canibais_dir+1, this.estado.miss_dir);
        if(this.estado.miss_esq > 1)
            this.check_esq_dir(this.estado.canibais_esq, this.estado.miss_esq-2, this.estado.canibais_dir, this.estado.miss_dir+2);
        if(this.estado.miss_esq > 0)
            this.check_esq_dir(this.estado.canibais_esq, this.estado.miss_esq-1, this.estado.canibais_dir, this.estado.miss_dir+1);
        if(this.estado.canibais_esq >= 1 && this.estado.miss_esq >= 1)
            this.check_esq_dir(this.estado.canibais_esq-1, this.estado.miss_esq-1, this.estado.canibais_dir+1, this.estado.miss_dir+1);
    }        
}
