package missionarios_canibais;

public class Estado {
    int canibais_esq;
    int canibais_dir;
    int miss_esq;
    int miss_dir;

    public Estado(int canibais_esq, int canibais_dir, int miss_esq, int miss_dir) {
        this.canibais_esq = canibais_esq;
        this.canibais_dir = canibais_dir;
        this.miss_esq = miss_esq;
        this.miss_dir = miss_dir;
    }
}

