package missionarios_canibais;

import java.util.ArrayList;

public class Missionarios_canibais {
    public static void main(String[] args) {
        Node node = new Node();
        BFS(node);
    }
    
    public static void BFS(Node start){
        ArrayList<Node> fronteira = new ArrayList<>();
        fronteira.add(start);
        while(!fronteira.isEmpty()){
            Node n = fronteira.get(0);
            fronteira.remove(0);
            if(n.isSolution()){
                System.out.println("Solução Encontrada\n" + n);
                break;
            }
            n.gerar_filho();
            for(int i =0;i<n.Filhos.size();i++){
                Node Filho = n.Filhos.get(i);
                fronteira.add(Filho);
                System.out.println(Filho);
            }
        }
    }
}
