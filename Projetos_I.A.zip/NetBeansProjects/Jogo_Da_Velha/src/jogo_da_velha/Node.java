package jogo_da_velha;

import java.util.ArrayList;

public final class Node {
    String[][] estado = new String[3][3];
    int valor = 0;
    int profundidade;
    int vez;
    ArrayList<Node> filhos = new ArrayList<Node>();

    public Node() {
    }

    public Node(Node pai){
        for (int i = 0; i < 3; i++) {
            System.arraycopy(pai.estado[i], 0, this.getEstado()[i], 0, 3);
        }
    }
    
    public Node(String[][] estado, int vez) {
        this.estado = estado;
        this.vez = vez;
        this.profundidade = 0;
    }
  
    public ArrayList<Node> Gera_Filhos(Node node, int vez){
        filhos = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                Node filho = new Node(node);
                if(vez == 0)
                    filho.setVez(1);
                else
                    filho.setVez(0);
                filho.setProfundidade(node.getProfundidade()+1);
                if (estado[i][j] == null) {   
                    if (filho.getVez() == 1) {
                        filho.setX(i, j);
                    } else {
                        filho.setO(i, j);
                    }
                    filho.setValor(filho.getResultado());
                    filhos.add(filho);
                }
            }
        }
        return filhos;
    }
    
    
    public void printa_estado() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(estado[i][j] + "\t");
            }
            System.out.println("");
        }
        System.out.println("GRAU: "+this.getValor());
    }
    
    private boolean verificaHorizontal(int linha) {
        return ("O".equals(estado[linha][0]) && "O".equals(estado[linha][1]) && "O".equals(estado[linha][2]));
    }

    private boolean verificaVertical(int coluna) {
        return ("O".equals(estado[0][coluna]) && "O".equals(estado[1][coluna]) && "O".equals(estado[2][coluna]));
    }

    private boolean verificaDiagonalPrincipal() {
        return ("O".equals(estado[0][0]) && "O".equals(estado[1][1]) && "O".equals(estado[2][2]));
    }

    private boolean verificaDiagonalSecundaria() {
        return ("O".equals(estado[0][2]) && "O".equals(estado[1][1]) && "O".equals(estado[2][0]));
    }

    private boolean verificaPerdeuHorizontal(int linha) {
        return ("X".equals(estado[linha][0]) && "X".equals(estado[linha][1]) && "X".equals(estado[linha][2]));
    }

    private boolean verificaPerdeuVertical(int coluna) {
        return ("X".equals(estado[0][coluna]) && "X".equals(estado[1][coluna]) && "X".equals(estado[2][coluna]));
    }

    private boolean verificaPerdeuDiagonalPrincipal() {
        return ("X".equals(estado[0][0]) && "X".equals(estado[1][1]) && "X".equals(estado[2][2]));
    }

    private boolean verificaPerdeuDiagonalSecundaria() {
        return ("X".equals(estado[0][2]) && "X".equals(estado[1][1]) && "X".equals(estado[2][0]));
    }
    
    public boolean empate() {
        boolean empate = true;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (estado[i][j] == null) {
                    empate = false;
                    break;
                }
            }
        }

        return empate && !ganhou();
    }
    
    //Verifica se o Computador Perdeu
    public boolean perdeu() {
        return (verificaPerdeuHorizontal(0)
                || verificaPerdeuHorizontal(1)
                || verificaPerdeuHorizontal(2)
                || verificaPerdeuVertical(0)
                || verificaPerdeuVertical(1)
                || verificaPerdeuVertical(2)
                || verificaPerdeuDiagonalPrincipal()
                || verificaPerdeuDiagonalSecundaria());
    }

    //Verifica se o computador ganhou
    public boolean ganhou() {
        return (   verificaHorizontal(0)
                || verificaHorizontal(1)
                || verificaHorizontal(2)
                || verificaVertical(0)
                || verificaVertical(1)
                || verificaVertical(2)
                || verificaDiagonalPrincipal()
                || verificaDiagonalSecundaria());
    }
    
    public boolean isTerminal() {
        return ganhou() || empate() || perdeu();
    }

    public int getVez() {
        return vez;
    }

    public void setVez(int vez) {
        this.vez = vez;
    }
    
    public int getResultado() {
        if(ganhou()) {
            valor = 200 - this.profundidade;
            return valor;
        }
        else {
            if (perdeu()) {
                valor = -200 + this.profundidade;
                return valor;
            } 
            else {
                return 0;
            }
        }
    }
    
    public String[][] getEstado() {
        return estado;
    }

    public void setEstado(String[][] estado) {
        this.estado = estado;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getProfundidade() {
        return profundidade;
    }

    public void setProfundidade(int profundidade) {
        this.profundidade = profundidade;
    }

    public ArrayList<Node> getFilhos() {
        return filhos;
    }

    public void setFilhos(ArrayList<Node> filhos) {
        this.filhos = filhos;
    }
    
    public void setX(int linha, int coluna) {
        estado[linha][coluna] = "X";
    }

    public void setO(int linha, int coluna) {
        estado[linha][coluna] = "O";
    }
}
