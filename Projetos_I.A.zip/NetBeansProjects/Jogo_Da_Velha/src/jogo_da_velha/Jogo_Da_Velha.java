package jogo_da_velha;

import java.util.Scanner;

public class Jogo_Da_Velha { //X é vc O é pc
    public static void main(String[] args) throws CloneNotSupportedException {
        int vez = 0;
        String[][] estado = new String[3][3];
        Scanner input = new Scanner(System.in);
        System.out.println("Digite 1 para jogar primeiro, ou 0 caso a máquina jogue primeiro");
        vez = input.nextInt();
        if(vez == 1){
            System.out.println("Escolha a posição onde deseja jogar, inserindo linha e coluna, respectivamente");
            estado[input.nextInt()][input.nextInt()] = "X";
        }
        else
            vez = 1;
        Node node = new Node(estado, vez);
        Node current = new Node();
        MiniMax minimax = new MiniMax();
        while(!(current.isTerminal())){
            current = minimax.minimaxDecision(node);
            if(current.isTerminal()) break;
            System.out.println("Escolha a posição onde deseja jogar, inserindo linha e coluna, respectivamente");
            current.estado[input.nextInt()][input.nextInt()] = "X";
            node.setEstado(current.getEstado());
            /*if(vez == 0)
                    node.setVez(1);
            else
                node.setVez(0);*/
        }
    }
}
