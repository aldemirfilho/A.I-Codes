package jogo_da_velha;

import java.util.ArrayList;

public class MiniMax {
    private int alfa = Integer.MIN_VALUE;
    private int beta = Integer.MAX_VALUE;

    public Node minimaxDecision(Node node) {
        int melhor = MaxValue(node);
        System.out.println(melhor + " melhor");
        ArrayList<Node> filhos = node.getFilhos();
        for (Node filho : filhos) {
            System.out.println("");
            if (filho.getValor() == melhor) {
                filho.printa_estado();
                return filho;
            }
        }
        return null;
    }

    public int MinValue(Node node){
        if (node.isTerminal()) {
            node.setValor(node.getResultado());
            return node.getValor();
        } 
        else {
            int minValue = Integer.MAX_VALUE;
            //node.setValor(Integer.MAX_VALUE);
            ArrayList<Node> filhos = node.Gera_Filhos(node, node.getVez());
            for (Node filho : filhos){ 
                minValue = Math.min(minValue, MaxValue(filho));
            }
            node.setValor(minValue);
            //System.out.println(minValue + " MinValue");
            return minValue;
        }
    }

    public int MaxValue(Node node){
        if (node.isTerminal()) {
            node.setValor(node.getResultado());
            return node.getValor();
        } else {
            int maxValue = Integer.MIN_VALUE;
            //node.setValor(Integer.MIN_VALUE);
            ArrayList<Node> filhos = node.Gera_Filhos(node, node.getVez());
            for (Node filho : filhos) {
                maxValue = Math.max(maxValue, MinValue(filho));
            }
            node.setValor(maxValue);
            //System.out.println(maxValue + " Maxvalue");
            return maxValue;
        }
    }
}
