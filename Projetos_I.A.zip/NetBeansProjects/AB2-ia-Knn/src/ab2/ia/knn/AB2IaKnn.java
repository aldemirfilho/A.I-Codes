package ab2.ia.knn;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;
import java.util.Arrays;
import java.util.Collections;

public class AB2IaKnn {
    
    public static String[][] ler_arquivo(int numero_linhas,int numero_colunas, String arquivo){
        BufferedReader conteudoCSV = null;
        
        String caminho_atual = new File("").getAbsolutePath();
        
        String caminho = caminho_atual + "/"+ arquivo;
        String separador = ",";
        String linha = null;
        String[][] dados = new String[numero_linhas+1][numero_colunas];
        try{
            conteudoCSV = new BufferedReader(new FileReader(caminho));
            int i = 0;
            while((linha = conteudoCSV.readLine()) != null){
                String[] atual = linha.split(separador);
                for(int j = 0; j < numero_colunas;j++){
                    dados[i][j] = atual[j];
                }
                i++;
            }
        }catch(IOException e){
            System.out.println("Error");
        }
        return dados;
    }
    
    public static double[][] transformar(String[][] dados, int tam_linhas, int tam_colunas){
        double dados1[][] = new double[tam_linhas][tam_colunas];
        int i= 0, j = 0;
        for(i = 0; i < tam_linhas; i++){
            for(j = 0; j < tam_colunas; j++){
                if(dados[i][j].equals("Sol")){
                   dados1[i][j] = 11;
                }
                else if(dados[i][j].equals(("Nuvens"))){
                   dados1[i][j] = 12;
                }
                else if(dados[i][j].equals(("Chuva"))){
                   dados1[i][j] = 13;
                }
                else if(dados[i][j].equals(("Quente"))){
                   dados1[i][j] = 14;
                }
                else if(dados[i][j].equals(("Ameno"))){
                   dados1[i][j] = 15;
                }
                else if(dados[i][j].equals(("Fresco"))){
                   dados1[i][j] = 16;
                }
                else if(dados[i][j].equals(("Elevada"))){
                   dados1[i][j] = 17;
                }else if(dados[i][j].equals(("Normal"))){
                   dados1[i][j] = 18;
                }
                else if(dados[i][j].equals(("Baixa"))){
                   dados1[i][j] = 19;
                }
                else if(dados[i][j].equals(("Fraco"))){
                   dados1[i][j] = 20;
                }
                else if(dados[i][j].equals(("Forte"))){
                   dados1[i][j] = 21;
                }
                else if(dados[i][j].equals(("S"))){
                   dados1[i][j] = 1;
                }
                else if(dados[i][j].equals(("N"))){
                   dados1[i][j] = 0;
                }
            }
        }
        return dados1;
    }
    
    public static double getMax(double[] inputArray){ 
    double maxValue = inputArray[1]; 
    for(int i=1;i < inputArray.length;i++){ 
      if(inputArray[i] > maxValue){ 
         maxValue = inputArray[i]; 
      } 
    } 
    return maxValue; 
  }
 
  // Method for getting the minimum value
  public static double getMin(double[] inputArray){
    double minValue = inputArray[1];
    for(int i=1;i<inputArray.length;i++){ 
      if((inputArray[i] != 0) && (inputArray[i] != 1) && (inputArray[i] < minValue)){ 
        minValue = inputArray[i]; 
      } 
    }
    return minValue; 
  } 
    
    public static double[][] normalizar(double[][] dados, int num_linhas, int num_colunas){
        double[][] min_max = new double[num_linhas][2];
        for(int i = 1;i < num_linhas;i++){
            min_max[i][0] = getMin(dados[i]);
            min_max[i][1] = getMax(dados[i]);
        }
        if(num_colunas == 6){
            for(int i = 1;i < num_linhas; i++){
                for(int j = 1; j < num_colunas - 1; j++){
                dados[i][j] = ((dados[i][j] - min_max[i][0]) / (min_max[i][1] - min_max[i][0]));
                }
            }
        }
        else if(num_colunas == 5){
            for(int i = 1;i < num_linhas; i++){
                for(int j = 1; j < num_colunas; j++){
                dados[i][j] = ((dados[i][j] - min_max[i][0]) / (min_max[i][1] - min_max[i][0]));
                }
            }
        }
        return dados;
    }
    
    public static double[][] sort_dist(double[][] distancias, int num_linhas, int num_colunas){
        double[] temp = new double[num_colunas];
        for (int i = 0; i < num_linhas; i++) {
            for (int j = 1; j < (num_linhas - i); j++) {
                if (distancias[j - 1][num_colunas] > distancias[j][num_colunas]) {
                    //swap elements  
                    temp = distancias[j - 1];
                    distancias[j - 1] = distancias[j];
                    distancias[j] = temp;
                }
            }
        }
        return distancias;
    }
    
    public static double[][] pegar_vizinhos(double[][] dados_treino, double[] dados_teste, int k, int num_linhas_teste, int num_linhas_treino, int num_colunas_teste_, int num_colunas_treino){
        double[][] vizinhos = new double[k][num_colunas_treino];
        double[][] distancias = new double[num_linhas_treino][num_colunas_treino+1];
        for(int i = 0; i < num_linhas_treino; i++){
            double distancia_atual = 0;
            for(int j = 0; j < num_colunas_treino - 1; j++){
                distancia_atual += pow((dados_treino[i][j] - dados_teste[j]), 2);
            }
            distancia_atual = sqrt(distancia_atual);
            for(int z = 0; z < num_colunas_treino; z++){
                distancias[i][z] = dados_treino[i][z];
            }
            distancias[i][num_colunas_treino] = distancia_atual;
        }
        distancias = sort_dist(distancias, num_linhas_treino, num_colunas_treino);
        for(int i = 1; i < k; i++){
            for(int j = 1; j < num_colunas_treino; j++){
                vizinhos[i][j] = distancias[i][j];
            }
        }
        return vizinhos;
    }
    
    public static double predicao(double[] dados_teste, double[][] dados_treino, int k, int num_linhas_teste, int num_linhas_treino, int num_colunas_teste_, int num_colunas_treino){
        double[][] vizinhos = new double[k][num_colunas_treino];
        vizinhos = pegar_vizinhos(dados_treino, dados_teste, k, num_linhas_teste, num_linhas_treino, num_colunas_teste_, num_colunas_treino);
        int cont_n = 0, cont_s = 0;
        for(int i = 0; i < k; i++){
           if((vizinhos[i][num_colunas_treino - 1]) == 0){
               cont_n++;
           }
           else if((vizinhos[i][num_colunas_treino - 1]) == 1){
               cont_s++;
            }
        }
        if(cont_n >= cont_s){
            return 0;  
        }
        else
            return 1;
    }
    
    public static double[] knn(double[][] dados_treino, double[][] dados_teste, int num_linhas_teste, int num_linhas_treino, int num_colunas_teste_, int num_colunas_treino, int k){
        double[] class_ = new double[num_linhas_teste];
        double result;
        for(int i = 1; i < num_linhas_teste;i++){
            result = predicao(dados_teste[i], dados_treino, k, num_linhas_teste, num_linhas_treino, num_colunas_teste_, num_colunas_treino);
            class_[i] = result;
        }
        return class_;
    }
    
    public static void main(String[] args) {
        String[][] dados_treino = new String[29][6];
        String[][] dados_teste = new String[49][5];
        double[] result_knn = new double[49];
        
        dados_treino = ler_arquivo(29,6,"treino_dados.csv");
        dados_teste = ler_arquivo(49, 5,"teste_dados.csv");
        double[][] dados1 = transformar(dados_treino, 29, 6);
        double[][] dados2 = transformar(dados_teste, 49, 5);
        dados1 = normalizar(dados1, 29, 6);
        dados2 = normalizar(dados2, 49, 5);
        result_knn = knn(dados1, dados2, 48, 28, 5, 6, 3);
        for(int i = 1; i < result_knn.length;i++){
            System.out.println("linha " + i + ": " + result_knn[i]);
        }
        double vp = 0, vn = 0, fp = 0, fn = 0;
        for(int j = 1;j < 29; j++){
            if(dados1[j][5] ==  result_knn[j]){
                if(dados1[j][5] == 1) vp++;
                else if(dados1[j][5] == 0) vn++;
            }
            else if(dados1[j][5] != result_knn[j]){
                if(dados1[j][5] == 1) fn++;
                else if(dados1[j][5] == 0) fp++;
            }
        }
        double acuracia = 0, tx_erro = 0;
        acuracia = ((vp + vn) / 28.0) * 100;
        tx_erro = ((fp + fn) / 28.0) * 100;
        System.out.println();
        System.out.println("Acuracia: " + acuracia + " %" + "\n" + "Taxa de erro: " + tx_erro + " %");
        
        double[][] matriz_confusa = new double[2][2];
        
        matriz_confusa[0][0] = vp;     
        matriz_confusa[0][1] = fn;     
        matriz_confusa[1][0] = fp;     
        matriz_confusa[1][1] = vn;
        
        System.out.println();
        System.out.println("Matriz de confusão: ");
        System.out.println("     | S | N |");
        System.out.println("--------------------");
        for (int i = 0; i < 2; i++) {
            if (i == 0) {
                System.out.print("S | ");
            } else {
                System.out.print("N | ");
            }
            for (int j = 0; j < 2; j++) {
                System.out.print(matriz_confusa[i][j] + " | ");
            }
            System.out.println();
            System.out.println("--------------------");
        }
        double precisao, recall;
        precisao = (vp / (vp + fp)) * 100;
        recall = (vp / (vp + fn)) * 100;
        
        System.out.println();
        System.out.println("Precisao: " + precisao + " %" + "\n" + "Recall: " + recall + " %");
    }
}
