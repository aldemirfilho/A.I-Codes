package metro_de_paris2;
import java.util.*;
public class Node {
    Node pai;
    ArrayList<Node> filhos;
    int estacao,dist_percorrida;
    double minutos;

    public Node(Node pai, int estacao, int dist_percorrida, double minutos) {
        this.pai = pai;
        this.estacao = estacao;
        this.dist_percorrida = dist_percorrida;
        this.minutos = minutos;
        filhos = new ArrayList<>();
    }
    
    public void gera_filhos(int [][]dist, Linha azul, Linha verde, Linha vermelha, Linha amarela){
        for(int i = 0; i < 14; i++){
            if(i != this.estacao){
                if(azul.Estacoes.contains(this.estacao) && azul.Estacoes.contains(i)){
                    double horas = this.minutos + (((double)dist[this.estacao][i])/30d)*60;
                    if(pai != null && azul.Estacoes.contains(pai.estacao) && !(azul.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && amarela.Estacoes.contains(pai.estacao) && !(amarela.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && vermelha.Estacoes.contains(pai.estacao) && !(vermelha.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && verde.Estacoes.contains(pai.estacao) && !(verde.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    Node node = new Node(this, i, this.dist_percorrida + dist[this.estacao][i], horas);
                    this.filhos.add(node);
                }
                if(amarela.Estacoes.contains(this.estacao) && amarela.Estacoes.contains(i)){
                    double horas = this.minutos + ((double)(dist[this.estacao][i])/30d)*60;
                    if(pai != null && azul.Estacoes.contains(pai.estacao) && !(azul.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && amarela.Estacoes.contains(pai.estacao) && !(amarela.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && vermelha.Estacoes.contains(pai.estacao) && !(vermelha.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && verde.Estacoes.contains(pai.estacao) && !(verde.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    Node node = new Node(this, i, this.dist_percorrida + dist[this.estacao][i], horas);
                    this.filhos.add(node);
                }
                if(vermelha.Estacoes.contains(this.estacao) && vermelha.Estacoes.contains(i)){
                    double horas = this.minutos + ((double)(dist[this.estacao][i])/30d)*60;
                    if(pai != null && azul.Estacoes.contains(pai.estacao) && !(azul.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && amarela.Estacoes.contains(pai.estacao) && !(amarela.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && vermelha.Estacoes.contains(pai.estacao) && !(vermelha.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && verde.Estacoes.contains(pai.estacao) && !(verde.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    Node node = new Node(this, i, this.dist_percorrida + dist[this.estacao][i], horas);
                    this.filhos.add(node);
                }
                if(verde.Estacoes.contains(this.estacao) && verde.Estacoes.contains(i)){
                    double horas = this.minutos + ((double)(dist[this.estacao][i])/30d)*60;
                    if(pai != null && azul.Estacoes.contains(pai.estacao) && !(azul.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && amarela.Estacoes.contains(pai.estacao) && !(amarela.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && vermelha.Estacoes.contains(pai.estacao) && !(vermelha.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    else if(pai != null && verde.Estacoes.contains(pai.estacao) && !(verde.Estacoes.contains(i))){
                        horas+= (2d/30d)*60;
                    }
                    Node node = new Node(this, i, this.dist_percorrida + dist[this.estacao][i], horas);
                    this.filhos.add(node);
                }
            }
        }
    }
    
    public void print_caminho(){
        if(pai != null)
            pai.print_caminho();
        if(filhos.size() != 0)
            System.out.print(estacao+1 + ",");
        else
             System.out.println(estacao+1);
    }
}
