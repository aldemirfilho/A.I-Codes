package metro_de_paris2;

import java.util.ArrayList;

public class Linha {
    java.util.ArrayList<Integer> Estacoes = new java.util.ArrayList<Integer>();

    public Linha(int []estacoes) {
        int i = 0;
        for(i = 0; i < estacoes.length; i++){
            this.Estacoes.add(estacoes[i]);
        }
    }
    
    
}
